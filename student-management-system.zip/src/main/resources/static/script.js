const form = document.getElementById("studentForm");
const idInput = document.getElementById("studentId");
const nameInput = document.getElementById("name");
const emailInput = document.getElementById("email");
const courseInput = document.getElementById("course");
const table = document.getElementById("studentTable");
const cancelBtn = document.getElementById("cancelBtn");

async function loadStudents() {
    const response = await fetch("/api/students");
    const students = await response.json();

    table.innerHTML = "";

    students.forEach(student => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td>${student.id}</td>
            <td>${student.name}</td>
            <td>${student.email}</td>
            <td>${student.course}</td>
            <td class="actions">
                <button onclick='editStudent(${JSON.stringify(student)})'>Edit</button>
                <button onclick='deleteStudent(${student.id})'>Delete</button>
            </td>
        `;
        table.appendChild(row);
    });
}

form.addEventListener("submit", async (event) => {
    event.preventDefault();

    const id = idInput.value;
    const student = {
        name: nameInput.value,
        email: emailInput.value,
        course: courseInput.value
    };

    const url = id ? `/api/students/${id}` : "/api/students";
    const method = id ? "PUT" : "POST";

    const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(student)
    });

    if (response.ok) {
        resetForm();
        loadStudents();
    } else {
        alert("Operation failed");
    }
});

function editStudent(student) {
    idInput.value = student.id;
    nameInput.value = student.name;
    emailInput.value = student.email;
    courseInput.value = student.course;
}

async function deleteStudent(id) {
    if (!confirm("Delete this student?")) return;

    const response = await fetch(`/api/students/${id}`, { method: "DELETE" });
    if (response.ok) {
        loadStudents();
    } else {
        alert("Delete failed");
    }
}

function resetForm() {
    idInput.value = "";
    form.reset();
}

cancelBtn.addEventListener("click", resetForm);

loadStudents();
